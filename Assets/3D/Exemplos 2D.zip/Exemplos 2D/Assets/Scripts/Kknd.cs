using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Kknd : MonoBehaviour
{
    public float kiko;
    public bool kaka;
    public double koko;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
