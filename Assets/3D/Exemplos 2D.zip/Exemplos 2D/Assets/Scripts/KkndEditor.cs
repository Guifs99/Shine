using UnityEngine;
using UnityEditor;

[CustomEditor(typeof(Kknd))]
[CanEditMultipleObjects]

public class KkndEditor : Editor
{
    SerializedProperty kk,ko,ki;

    public void OnEnable()
    {
        kk = serializedObject.FindProperty("kaka");
        ko = serializedObject.FindProperty("koko");
        ki = serializedObject.FindProperty("kiko");
    }
    public override void OnInspectorGUI()
    {
        EditorGUILayout.PropertyField(kk, new GUIContent("Seletor"));
        if (kk.boolValue)
        {
            EditorGUILayout.PropertyField(ko,new GUIContent("koroline"));
           
        }
        else
        {
            EditorGUILayout.PropertyField(ki);
        }

        serializedObject.ApplyModifiedProperties();
    }
}
